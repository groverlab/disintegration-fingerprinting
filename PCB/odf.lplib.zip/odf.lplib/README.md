# odf

## Description

This is a [LibrePCB](https://librepcb.org) library!
Just edit this file to add a description about it.

## License

No license set.
